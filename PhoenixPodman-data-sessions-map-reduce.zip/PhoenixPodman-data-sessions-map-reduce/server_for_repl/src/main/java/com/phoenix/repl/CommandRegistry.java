package com.phoenix.repl;

import com.amazon.ion.IonSystem;
import com.amazon.ion.IonWriter;
import com.amazon.ion.system.IonSystemBuilder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPOutputStream;

public final class CommandRegistry {
    private Map<String, CommandInterface> registryMap = new ConcurrentHashMap<>();
    private byte [] registeredCommands;
    CommandRegistry(){
        init();
    }
    public void init(){

        List<CommandInterface> commandList = new ArrayList<>();
        commandList.add(new AddCommand());
        commandList.add(new SubCommand());
        commandList.add(new MulCommand());
        commandList.add(new DivCommand());
        commandList.add(new GetObj());
        commandList.add(new StatusCommand());
        commandList.add(new CancelCommand());

        List<String> registeredClassesDescription = new ArrayList<>();

        for(CommandInterface cmd : commandList){
            registryMap.putIfAbsent(cmd.getName(), cmd);
            registeredClassesDescription.add(cmd.getDescription());
        }
        IonWriter ionWriter = null;
        GZIPOutputStream gzipOutputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;

        try {
            IonSystem ionSystem = IonSystemBuilder.standard().build();

            byteArrayOutputStream = new ByteArrayOutputStream();
            gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream);

            ionWriter = ionSystem.newBinaryWriter(gzipOutputStream);

            for (String ionString : registeredClassesDescription) {
                ionWriter.writeString(ionString);
            }
        }catch (Exception e){
            throw new RuntimeException(e);
        }finally {
            try {
                ionWriter.close();
                gzipOutputStream.close();
                byteArrayOutputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        registeredCommands = byteArrayOutputStream.toByteArray();
    }

    public Map<String, CommandInterface> getRegistryMap() {
        return registryMap;
    }

    public byte[] getRegisteredCommands() {
        return registeredCommands;
    }
}
