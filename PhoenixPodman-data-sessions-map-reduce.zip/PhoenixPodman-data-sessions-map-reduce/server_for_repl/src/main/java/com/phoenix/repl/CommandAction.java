package com.phoenix.repl;

import com.amazon.ion.IonSystem;
import com.amazon.ion.IonType;
import com.amazon.ion.IonWriter;
import com.amazon.ion.Timestamp;
import com.amazon.ion.system.IonSystemBuilder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPOutputStream;

public class CommandAction {

    public enum Status
    {
        success,
        fail,
        inProgress,
        terminated
    }
    int transactionId;
    private Status status;
    private CommandInterface commandInterface;
    private Timestamp lastUpdated;
    public void setStatus(String status) {
        this.status = Status.valueOf(status);
    }
    public Status getStatus() {
        return status;
    }
    public void setStatus(Status status) {
        this.status = status;
    }
    public Timestamp getLastUpdated() {
        return lastUpdated;
    }
    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    public int getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }
    public CommandInterface getCommandInterface() {
        return commandInterface;
    }
    public void setCommandInterface(CommandInterface commandInterface) {
        this.commandInterface = commandInterface;
    }
    CommandAction(int transactionId, CommandInterface commandInterface, String status, Timestamp lastUpdated){
        this.transactionId = transactionId;
        this.commandInterface = commandInterface;
        this.status = Status.valueOf(status);
        this.lastUpdated = lastUpdated;
    }
    public static byte [] convertToZippedByteArray(CommandAction cmdResult) throws IOException {
        IonSystem ionSystem = IonSystemBuilder.standard().build();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        GZIPOutputStream gzipOutputStream = new GZIPOutputStream(outputStream);
        // Create an IonWriter with the binary format
        IonWriter ionWriter = ionSystem.newBinaryWriter(gzipOutputStream);
        ionWriter.stepIn(IonType.STRUCT);

        ionWriter.setFieldName(String.valueOf(Constants.lastUpdated));
        ionWriter.writeTimestamp(cmdResult.getLastUpdated());

        ionWriter.setFieldName(String.valueOf(Constants.status));
        ionWriter.writeSymbol(cmdResult.getStatus().name());


        ionWriter.setFieldName(String.valueOf(Constants.transactionId));
        ionWriter.writeInt(cmdResult.getTransactionId());

        cmdResult.getCommandInterface().toIon(ionWriter);

        ionWriter.stepOut();
        ionWriter.close();

        gzipOutputStream.close();
        outputStream.close();

        return outputStream.toByteArray();
    }
}