package com.okta;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Client {

    public static void main(String [] args) throws IOException {

        System.out.println("Initialize the username ");

        Authenticate authenticateApi = new Authenticate();

        String token = authenticateApi.getToken();
        System.out.println(token);

        String getHello = getCall(token);
        if(getHello == null)
            System.out.println("Could not invoke the get call");
        else
            System.out.println(getHello);
    }

    private static String getCall(String token){
        String url = "http://localhost:8080/hello";

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .headers("Content-Type", "application/x-www-form-urlencoded",
                            "Authorization", "Basic " + Authenticate.encodedCredentials,
                            "Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString("token="+token))
                    .build();

            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<?> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            return response.body().toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
