package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.AuthenticationService;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HttpString;

public class TokenValidatorMiddleware implements HttpHandler {
    private final HttpHandler next;

    public TokenValidatorMiddleware(HttpHandler next){
        this.next = next;
    }

    @Override
    public void handleRequest(HttpServerExchange httpServerExchange) throws Exception {
        String token = httpServerExchange.getRequestHeaders().getFirst(new HttpString("Token"));
        if (token == null) {
            httpServerExchange.setStatusCode(401); // Unauthorized
            httpServerExchange.getResponseSender().send("Unauthorized: Missing or invalid authorization");
            return;
        }

        boolean isValidToken = validateToken(token); // token=

        if (!isValidToken) {
            httpServerExchange.setStatusCode(401); // Unauthorized
            httpServerExchange.getResponseSender().send("Unauthorized: Invalid token");
            return;
        }

        // Token is valid, proceed with the next handler
        next.handleRequest(httpServerExchange);
    }
    private boolean validateToken(String token){
        return AuthenticationService.isTokenValid(token);
    }
}
