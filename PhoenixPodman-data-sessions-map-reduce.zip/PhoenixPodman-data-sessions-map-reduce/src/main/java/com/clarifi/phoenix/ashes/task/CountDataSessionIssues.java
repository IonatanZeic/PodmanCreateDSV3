package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.node.SimpleExecutorService;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import static com.clarifi.phoenix.ashes.server.ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS;

public class CountDataSessionIssues implements IgniteCallable<Integer> {
    @IgniteInstanceResource
    Ignite ignite;

    private final String userId;
    private final boolean useThreadingLibrary;

    public CountDataSessionIssues(final String userId, final boolean useThreadingLibrary) {
        this.userId = userId;
        this.useThreadingLibrary = useThreadingLibrary;
    }

    @Override
    public Integer call() throws ExecutionException, InterruptedException {
//        task.setStatus(PhoenixTask.Status.Running);
//        task.setProgress(0.1d);

        final String cacheName = String.format("%s:%s", PREFIX_CACHE_USER_DATA_SESSIONS, userId.toString());
        final IgniteCache<UUID, PackedDataSession> cache = ignite.cache(cacheName);

        final SimpleExecutorService service = ignite.services().serviceProxy(
                "MyExecutorService", SimpleExecutorService.class, true);

        final Future<Integer> future;
        if (useThreadingLibrary) {
            future = service.submitToTL(new CountIssuesUsingThreadingLibrary(
                cache,
                service.getTLPool()
            ));

            System.out.printf(
                    "{Thread:%s} Total issues for user (TL): %d\n",
                    Thread.currentThread().getName(),
                    future.get());
        } else {
            future = service.submitToJDK(new Callable<Integer>() {
                @Override
                public Integer call() {
                    // todo: find a faster way to get all the keys instead of iterating the entire cache
                    final List<UUID> sessions = new ArrayList<>();
                    for (final Cache.Entry<UUID, PackedDataSession> uuidDataSessionEntry : cache) {
                        sessions.add(uuidDataSessionEntry.getKey());
                    }

                    final IgniteCompute compute = ignite.compute();

                    final CountIssuesUsingIgniteMapReduce tasks = new CountIssuesUsingIgniteMapReduce(UUID.fromString(userId));
                    final Integer result = compute.execute(tasks, sessions);

                    System.out.printf(
                        "{Thread:%s} Total issues for user %s: %d\n",
                        Thread.currentThread().getName(),
                        userId,
                        result.intValue()
                    );

                    return result;
                }
            });
        }

        final Integer result;
        try {
            result = future.get();
        } catch (final InterruptedException interrupted) {
            System.err.println("Interrupted while waiting for the task to complete");

            return Integer.valueOf(-1);
        } catch (final ExecutionException ex) {
            ex.printStackTrace(System.err);

            return Integer.valueOf(-2);
        }

//        task.setStatus(PhoenixTask.Status.Completed);

        return result;
    }
}
