package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

/**
 * A class to access sample data from an Ignite cache
 */
public class AccessSampleData {

  public static void main(String[] args) throws IgniteException {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    // Create an IgniteCache and put some values in it.
    IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache = ignite.cache(Common.TIMESERIES_DATA_CACHE);
    accessTimeSeriesCache(tsCache);
    
    int[] keys = {2, 44, 34};
    // Create an IgniteCache and put some values in it.
    IgniteCache<Integer, String> cache = ignite.getOrCreateCache(Common.SAMPLE_CACHE);

    for (int i = 0; i < keys.length; ++i) {
      int key = keys[i];
      String v = cache.get(key);

      System.out.println(">>> key = " + key + ", value = " + v);
    }

    // Disconnect from the cluster.
    ignite.close();
  }

  private static void accessTimeSeriesCache(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache) {
    int issueId = TimeSeriesDataCache.generateIssueId(5);
    int dataItemId = TimeSeriesDataCache.generateDataItemId(7);

    TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);
    TimeSeriesData ts = tsCache.get(key);

    dumpTSData(getTimeSeriesData(tsCache, 5,7));
    dumpTSData(getTimeSeriesData(tsCache, 17,27));
    dumpTSData(getTimeSeriesData(tsCache, 717,84));

    dumpTSData(getTimeSeriesData(tsCache, 11117,527));

  }

  private static TimeSeriesData getTimeSeriesData(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache, int issueIdx, int dataItemIdx) {
    int issueId = TimeSeriesDataCache.generateIssueId(issueIdx);
    int dataItemId = TimeSeriesDataCache.generateDataItemId(dataItemIdx);

    TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);
    TimeSeriesData ts = tsCache.get(key);

    return ts;
  }

  private static void dumpTSData(TimeSeriesData ts) {
    if (ts == null) {
      System.out.println("NULL");
      return;
    }
    System.out.println(">>>> issueId = " + ts.issueId + ", dataItemId = " + ts.dataItemId);
    for (int i = 0; (i < 5) && (i < ts.dates.length); ++i) {
      System.out.println("\t\tdateId = " + ((int) ts.dates[i])+ ", value = " + ts.values[i]);
    }
  }
}
