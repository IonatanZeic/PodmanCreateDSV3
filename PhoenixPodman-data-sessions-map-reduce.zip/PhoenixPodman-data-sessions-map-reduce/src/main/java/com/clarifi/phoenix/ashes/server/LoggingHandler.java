package com.clarifi.phoenix.ashes.server;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;

public class LoggingHandler implements HttpHandler {
    private final HttpHandler next;

    public LoggingHandler(final HttpHandler next) {
        this.next = next;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        System.out.printf("{Thread:%s} Request method: %s, Request path: %s, Request body size: %d\n",
            Thread.currentThread().getName(),
            exchange.getRequestMethod(),
            exchange.getRequestPath(),
            exchange.getRequestContentLength()
        );

        next.handleRequest(exchange);
    }
}
