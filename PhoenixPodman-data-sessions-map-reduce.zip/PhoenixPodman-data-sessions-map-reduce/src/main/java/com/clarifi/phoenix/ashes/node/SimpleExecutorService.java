package com.clarifi.phoenix.ashes.node;

import com.clarifi.concurrent.batch.BatchingThreadPool;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public interface SimpleExecutorService {
    ExecutorService getExecutor();

    void submitToJDK(Runnable task);
    <V> Future<V> submitToJDK(Callable<V> callable);

    void submitToTL(Runnable task);
    <V> Future<V> submitToTL(Callable<V> callable);

    BatchingThreadPool getTLPool();
}
