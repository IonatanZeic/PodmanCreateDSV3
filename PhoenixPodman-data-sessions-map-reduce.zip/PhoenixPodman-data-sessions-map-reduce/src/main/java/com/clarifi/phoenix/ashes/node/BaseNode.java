package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Stoppable;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseNode extends Stoppable implements Runnable {

  private static Log LOG = LogFactory.getLog(BaseNode.class);

  /** A static reference to the Node's command line arguments */
  private static String[] _commandLineArgs;

  /** A static reference to the Client */
  private volatile static BaseNode _client;

  /** The Clients's Thread. */
  private volatile Thread _mainThread;

  /** The exit code to exit with. */
  private Integer _exitCode = null;

  /** A flag to know if the Node has been fully initialized */
  protected boolean _fullyInitialized;

  /**
   * Gets current version of ModelStation.
   * @return the version.
   */
  public static String getVersion()
  {
    return "0.0";
  }

  /**
   * Construct the application. Run in our own thread.
   * Make protected so nothing else can create a Client.
   */
  protected BaseNode()
  {
    _fullyInitialized = false;

    //output the version for diagnostics in case something trips
    System.out.println("com.clarifi.phoenix.ashes.node.BaseNode.<init>: creating _mainThread");

    //start the main thread
    _mainThread = new Thread(this, "NodeThread::" + getNodeDescription());

    //don't start the thread here - need to let the main method start it up,
    //  else there can be threading issues looking up the static client reference --AFG

  }

  public abstract String getNodeDescription();

  private Thread getMainThread()
  {
    return _mainThread;
  }

  /**
   * An initializer method for the Client. Handles all initialization.
   * If anything fails to initialize, we log a fatal error and exit.
   */
  protected abstract void initNode() throws Throwable;

  /**
   * The hook to provide for shutting down whatever was initialized
   * and whatever else needs to be shut down.
   */
  protected abstract void doShutdown();

  /**
   * This method waits until the Client wants to shutDown. It blocks until until
   * signalClientExit() is called. This enforces that the Client's main thread
   * is the only thread that shuts down the Client and exits.
   */
  private final void waitForShutDown()
  {
    while (stillAlive())
    {
      try
      {
        synchronized (this)
        {
          _fullyInitialized = true;

          //this will wait until signaled or an exception is thrown
          wait();
        }
      }
      catch (Throwable t)
      {
        LOG.error("ERROR in waiting to shutdown!", t);
      }
    }
  }


  /**
   * This is the thread that the Client runs in.
   * This wraps the rest of Client's initialization and then waits for death.
   */
  public final void run()
  {
    try
    {
      LOG.info("Initializing ClariFI Client: " + getClass().getSimpleName() + ", Version: "+getVersion()+"...");
      LOG.info("Java version: " + System.getProperty( "java.version", "?" ) );
      LOG.info("Operating System: " + System.getProperty("os.name") + " (" + System.getProperty("os.version") + ")" );

      //this will capture CTRL-C as an exit command
      Runtime.getRuntime().addShutdownHook(new ShutdownHookThread());

      //now do concrete init
      initNode();

      //Wait for shutdown
      if (stillAlive())
      {
        LOG.info("Client Initialized. Client: " + getNodeDescription(), null);

        //set thread name properly
        try {Thread.currentThread().setName("ClientThread::" + getNodeDescription());}
        catch (Exception ex) {}

        //Ok, here we are initialized. And everything should be running fine.

        //We now wait until the Client wants to shutDown.
        //waitForShutDown() will block until signalClientExit() is
        //called.  We then call doShutDown and exit the JVM.
        waitForShutDown();
      }
    }
    catch (Throwable t)
    {
      LOG.fatal("Fatal Error in Client.run! ID: " + getNodeDescription(), t);
    }
    finally
    {
      //always try to shut the client down
      shutdownClient(getExitCode());
    }
  }

  /**
   * Sets the exitCode attribute of the Client object
   * @param exitCode  The new exitCode value
   */
  private final synchronized void setExitCode(int exitCode)
  {
    if (_exitCode == null)
      _exitCode = exitCode;
    else
    {
      LOG.warn("Cannot set the exit code more than once. It has already been set to: "+
          _exitCode.intValue() + ", so we cannot set it to: " + exitCode,
        new Exception("Cannot set the exit code more than once."));
    }
  }

  /**
   * Gets the exitCode attribute of the Client object
   * @return   The exitCode value
   */
  private final synchronized int getExitCode()
  {
    if (_exitCode == null)
      return 0;
    else
      return _exitCode.intValue();
  }

  public boolean canExit()
  {
    return true;
  }


  /**
   * The maximum number of seconds that the client will wait in the shutdown
   * logic before forcing an exit
   */
  private static final int MAX_SHUTDOWN_TIMEOUT_SECS = 30;


  /** Shuts down all services tied to this Client. */
  private void shutdownClient(int exitStatus)
  {
    final String desc = getNodeDescription();
    LOG.info("Shutting down Node: " + desc);

    Thread shutdownThread = new Thread("Shutdown Thread")
    {
      @Override
      public void run()
      {
        //do the shutdown
        try
        {
          doShutdown();
        }
        catch (Throwable t)
        {
          LOG.warn("Unexpected error in doShutdown. Client: " + desc, t);
        }

        LOG.info("Node Shutdown. Node: " + desc);
      }
    };

    shutdownThread.start();

    //now wait for it to finish shutting down
    try
    {
      shutdownThread.join(MAX_SHUTDOWN_TIMEOUT_SECS * 1000);
    }
    catch (Exception ex)
    {
      LOG.warn("Error joining on shutdown thread for Client: " + desc, ex);
    }


    if (shutdownThread.isAlive())
    {
      //doh, we are gonna force an exit
      LOG.warn("Shutdown process has timed out after "+MAX_SHUTDOWN_TIMEOUT_SECS+
          " seconds. Forcing an exit now for Client: " + desc);
    }

    //notify sub-classes that care that we are about to exit
    aboutToExitGracefully();

    //now exit
    exit(exitStatus);
  }

  /** Hook for subclasses to know when we're about to exit */
  protected void aboutToExitGracefully() {}

  /**
   * A exit method that the Client can call to kill the JVM.
   * This should be the ONLY method in the client that calls System.exit()
   *
   * @param status  Description of the Parameter
   */
  protected final static void exit(int status)
  {
    LOG.info("Exiting Node with status: " + status);
    System.exit(status);
  }


  protected static void nodeMain(String[] args, Class nodeSubclass) throws Throwable
  {
    //output the version for diagnostics in case something trips
    System.out.println("Launching Ignite Node Client, Version: " + getVersion());

    try
    {
      //cache the command line args
      _commandLineArgs = args;

      //now construct and run our Client
      _client = (BaseNode) nodeSubclass.getDeclaredConstructor().newInstance();

      // now start the main thread. Need to wait until here to start it
      //  to guarantee that the _client field is set --AFG
      _client.getMainThread().start();
    }
    catch (Throwable t)
    {
      LOG.fatal("Fatal Error in com.clarifi.phoenix.ashes.node.BaseNode.nodeMain!", t);
      throw t;
    }
  }


  private volatile boolean _shuttingDown = false;
  private volatile boolean _aboutToExitGracefully = false;

  private class ShutdownHookThread extends Thread
  {
    private ShutdownHookThread()
    {
      super("com.clarifi.phoenix.ashes.node.BaseNode.ShutdownHookThread");
      setDaemon(true);
    }

    @Override
    public void run()
    {
      //only invoke a shutdown if we are not already shutting down
      if (!_shuttingDown)
      {
        try
        {
          LOG.info("Signaling shutdown of Node via shutdown hook...");

          if (!attemptForcedExit())
            LOG.info("Unable to shutdown the Node.");

          //need to wait until the client is about to exit
          while(!_aboutToExitGracefully)
            try {Thread.sleep(10);} catch (Exception e){/** Ignored */}

          //sleep a little bit more
          try {Thread.sleep(250);} catch (Exception e){/** Ignored */}

          LOG.info("Shutdown hook exited.");
        }
        catch (Throwable t)
        {
          LOG.warn("Error shutting down Node via shutdown hook", t);
        }
      }
    }
  }

  protected final boolean attemptForcedExit()
  {
    return attemptToSignalClientExit();
  }

  public final boolean attemptToSignalClientExit()
  {
    boolean doExit = true;

    if (doExit)
    {
      displayMsg("Shutting down Node...");
      LOG.info("Shutting down Node...");

      disableShutdownHook();
      signalClientExit(0);

      LOG.info("Node successfully signaled to shutdown.");
    }

    return doExit;
  }

  public void disableShutdownHook()
  {
    _shuttingDown = true;
  }

  /** Signals the Client to die. */
  public final synchronized void signalClientExit(int exitCode)
  {
    setExitCode(exitCode);
    signalDeath(); //set flag so Client dies
    notifyAll();  //signal Client's main thread to wake up and it will then die.
  }


  protected void displayMsg(String msg)
  {
     System.out.println(msg);
  }


}
