package com.clarifi.phoenix.ashes.data;

import com.clarifi.phoenix.ashes.data.TimeSeriesData;

public class IssueCalculationResult {
  public int numIssues;
  public int[] issueIds;
  public TimeSeriesData[] data;

  public IssueCalculationResult(int numIssues) {
    this.numIssues = numIssues;
    issueIds = new int[numIssues];
    data = new TimeSeriesData[numIssues];
  }
}
