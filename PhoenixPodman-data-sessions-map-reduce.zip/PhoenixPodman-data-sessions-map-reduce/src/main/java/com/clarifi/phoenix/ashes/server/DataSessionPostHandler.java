package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.task.BuildDataSession;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderValues;
import io.undertow.util.Headers;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.lang.IgniteFuture;
import org.apache.ignite.lang.IgniteInClosure;

import java.io.IOException;
import java.io.InputStream;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

public class DataSessionPostHandler extends CreateDataSessionHandler implements HttpHandler {
    private final ServerApp server;
    private int timeoutS = 5;

    public DataSessionPostHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        handleParams(exchange);

        final PackedDataSession session = parseDataSession(exchange);

        final Ignite ignite = server.getIgnite();
        final IgniteCache<UUID, PackedDataSession> cache = getOrCreateUserCache(ignite, session.getUserId().toString());
        if (cache.containsKey(session.getId())) {
            exchange.setStatusCode(StatusCodes.BAD_REQUEST);

            final String message = String.format("Data session with id '%s' already exists", session.getUserId());
            exchange.getResponseSender().send(message);
        } else {
            session.setStatus(DataSession.Status.Initializing);
            cache.put(session.getId(), session);

            final long startedAt = System.nanoTime();
            final IgniteCompute compute = ignite.compute(ignite.cluster().forServers());

            final IgniteFuture<Boolean> future = compute.callAsync(new BuildDataSession(session, cache.getName()));
            try {
                final Boolean result = future.get(timeoutS, TimeUnit.SECONDS);
                sendSessionResult(session, result, exchange);
            } catch (final IgniteException ex) {
                // todo: look for a better way of detecting timeout
                if (!future.isCancelled() && !future.isDone()) {
                    sendSessionStatus(session, exchange);

                    future.listen(new IgniteInClosure<IgniteFuture<Boolean>>() {
                        @Override
                        public void apply(final IgniteFuture<Boolean> future) {
                            final double millis = (System.nanoTime() - startedAt) / 1_000_000d;

                            System.out.printf(
                                    "Data session '%s' built after %.2f seconds\n",
                                    session.getId(),
                                    Double.valueOf(millis / 1000d)
                            );
                        }
                    });
                } else {
                    sendSessionError(session, ex, exchange);

                    session.setStatus(DataSession.Status.Failed);
                    cache.put(session.getId(), session);
                }
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }

        exchange.endExchange();
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }

    private static PackedDataSession parseDataSession(HttpServerExchange exchange) throws IOException {
        final byte[] bytes;

        final HeaderValues requestEncoding = exchange.getRequestHeaders().get(Headers.CONTENT_ENCODING);
        if (requestEncoding != null && requestEncoding.contains(ENCODING_GZIP)) {
            final GZIPInputStream input = new GZIPInputStream(exchange.getInputStream());
            bytes = input.readAllBytes();
        } else {
            final InputStream input = exchange.getInputStream();
            bytes = input.readAllBytes();
        }

        final PackedDataSession.Reader reader = new PackedDataSession.IonReader();
        return (PackedDataSession) reader.read(bytes);
    }
}
