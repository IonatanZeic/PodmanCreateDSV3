package com.clarifi.phoenix.ashes.common;

import java.time.Instant;
import java.util.UUID;

public class PortfolioDataSession implements DataSession {
    // todo: Will use a portfolio for obtaining the list of issue ids

    @Override
    public UUID getId() {
        return null;
    }

    @Override
    public UUID getUserId() {
        return null;
    }

    @Override
    public PhoenixDateRange getRange() {
        return null;
    }

    @Override
    public Status getStatus() {
        return Status.Failed;
    }

    @Override
    public int[] getIssues() {
        return new int[0];
    }

    @Override
    public int[] getDataItems() {
        return new int[0];
    }

    @Override
    public Instant getLastAccessedAt() {
        return Instant.EPOCH;
    }

    @Override
    public void updateLastAccessedAt() {
        // intentionally left blank
    }
}

