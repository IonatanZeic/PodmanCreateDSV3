package com.clarifi.phoenix.apiserver.handlers.diagnostic;

import java.time.Duration;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;

public class DiagnosticHandlers
{
  /**
   * Add a fixed delay before execution of the next handler
   *
   * @param next
   * @param duration
   * @return
   */
  public static DelayedExecutionHandler fixedDelay( HttpHandler next, Duration duration )
  {
    Function<HttpServerExchange, Duration> function = ( HttpServerExchange exchange ) -> duration;
    return new DelayedExecutionHandler( next, function );
  }

  /**
   * Add a random delay between minDuration (inclusive) and
   * maxDuration (exclusive) before execution of the next handler.
   * This can be used to add artificial latency for requests.
   *
   * @param next
   * @param minDuration inclusive
   * @param maxDuration exclusive
   * @param unit
   * @return
   */
  public static DelayedExecutionHandler randomDelay( HttpHandler next, long minDuration, long maxDuration, TimeUnit unit )
  {
    Function<HttpServerExchange, Duration> function = ( HttpServerExchange exchange ) ->
    {
      long duration = ThreadLocalRandom.current().nextLong( minDuration, maxDuration );
      return Duration.ofMillis( unit.toMillis( duration ) );
    };
    return new DelayedExecutionHandler( next, function );
  }
}
