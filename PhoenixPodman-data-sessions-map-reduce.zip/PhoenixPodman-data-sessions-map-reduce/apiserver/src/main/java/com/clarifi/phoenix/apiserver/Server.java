package com.clarifi.phoenix.apiserver;

import io.undertow.Undertow;
import io.undertow.UndertowOptions;

public class Server
{
  private static final int    DEFAULT_PORT = 8080;
  private static final String DEFAULT_HOST = "0.0.0.0"; //DP: attach to all interfaces

  public static void main( String[] args )
  {
    // Once again pull in a bunch of common middleware.
    Undertow.Builder undertow = Undertow.builder()
      //This setting is needed if you want to allow '=' as a value in a cookie.
      //If you base64 encode any cookie values you probably want it on.
      .setServerOption( UndertowOptions.ALLOW_EQUALS_IN_COOKIE_VALUE, true )
      // Needed to set request time in access logs
      .setServerOption( UndertowOptions.RECORD_REQUEST_START_TIME, true )
      .addHttpListener( DEFAULT_PORT, DEFAULT_HOST, Router.ROUTER );

    undertow.build().start();

  }
}
